import "./App.css";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Dashboard from "./components/Dashboard";
import ProductDetail from "./components/ProductDetail";
import AdminProducts from "./pages/AdminProducts";

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Dashboard />} />
        <Route path="/producto/:id" element={<ProductDetail />} />
        <Route path="/admin/productos" element={<AdminProducts  />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;