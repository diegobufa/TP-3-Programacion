import { useEffect, useState } from "react";

import AdminSidebar from "../components/adminProducts/AdminSidebar";
import AdminTopbar from "../components/adminProducts/AdminTopbar";
import AdminProductToolbar from "../components/adminProducts/AdminProductToolbar";
import ProductAdminForm from "../components/adminProducts/ProductAdminForm";
import ProductPreview from "../components/adminProducts/ProductPreview";
import ProductTable from "../components/adminProducts/ProductTable";

import { initialForm } from "../constants/productConstants";

import {
  getProducts,
  createProduct,
  updateProduct,
  deleteProduct,
} from "../services/productApi";

const AdminProducts = () => {
  const [productos, setProductos] = useState([]);
  const [form, setForm] = useState(initialForm);
  const [editandoId, setEditandoId] = useState(null);
  const [mostrarFormulario, setMostrarFormulario] = useState(false);
  const [busqueda, setBusqueda] = useState("");
  const [categoriaFiltro, setCategoriaFiltro] = useState("Todas");
  const [errores, setErrores] = useState({});
  const [loading, setLoading] = useState(false);

  const obtenerProductos = async () => {
    try {
      const data = await getProducts();
      setProductos(data);
    } catch (error) {
      console.log("Error al obtener productos:", error);
    }
  };

  useEffect(() => {
    obtenerProductos();
  }, []);

  const validarFormulario = () => {
    const nuevosErrores = {};

    if (!form.nombre.trim()) {
      nuevosErrores.nombre = "El nombre es obligatorio";
    }

    if (!form.descripcion.trim()) {
      nuevosErrores.descripcion = "La descripción es obligatoria";
    }

    if (form.precio === "" || Number(form.precio) <= 0) {
      nuevosErrores.precio = "El precio debe ser mayor a 0";
    }

    if (form.stock === "" || Number(form.stock) < 0) {
      nuevosErrores.stock = "El stock no puede ser negativo";
    }

    if (!form.categoria.trim()) {
      nuevosErrores.categoria = "La categoría es obligatoria";
    }

    if (!form.imageUrl.trim()) {
      nuevosErrores.imageUrl = "La URL de imagen es obligatoria";
    }

    setErrores(nuevosErrores);

    return Object.keys(nuevosErrores).length === 0;
  };

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;

    setForm({
      ...form,
      [name]: type === "checkbox" ? checked : value,
    });
  };

  const limpiarFormulario = () => {
    setForm(initialForm);
    setEditandoId(null);
    setErrores({});
  };

  const abrirNuevoProducto = () => {
    limpiarFormulario();
    setMostrarFormulario(true);
  };

  const cerrarFormulario = () => {
    limpiarFormulario();
    setMostrarFormulario(false);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!validarFormulario()) return;

    setLoading(true);

    const productoEnviar = {
      ...form,
      precio: Number(form.precio),
      stock: Number(form.stock),
    };

    try {
      if (editandoId) {
        await updateProduct(editandoId, productoEnviar);
      } else {
        await createProduct(productoEnviar);
      }

      await obtenerProductos();
      limpiarFormulario();
      setMostrarFormulario(false);
    } catch (error) {
      console.log(error);
      alert("Error al guardar el producto");
    } finally {
      setLoading(false);
    }
  };

  const editarProducto = (producto) => {
    setForm({
      nombre: producto.nombre || "",
      descripcion: producto.descripcion || "",
      precio: producto.precio || "",
      stock: producto.stock || "",
      categoria: producto.categoria || "Electrodomesticos",
      imageUrl: producto.imageUrl || "",
      disponibilidad: producto.disponibilidad ?? true,
      oferta: producto.oferta ?? false,
    });

    setEditandoId(producto.id);
    setMostrarFormulario(true);
    setErrores({});
  };

  const eliminarProducto = async (id) => {
    const confirmar = window.confirm(
      "¿Seguro que querés eliminar este producto?",
    );

    if (!confirmar) return;

    try {
      await deleteProduct(id);
      await obtenerProductos();
    } catch (error) {
      console.log(error);
      alert("Error al eliminar el producto");
    }
  };

  const productosFiltrados = productos.filter((producto) => {
    const texto = busqueda.toLowerCase();

    const coincideBusqueda =
      producto.nombre?.toLowerCase().includes(texto) ||
      producto.categoria?.toLowerCase().includes(texto) ||
      producto.descripcion?.toLowerCase().includes(texto);

    const coincideCategoria =
      categoriaFiltro === "Todas" || producto.categoria === categoriaFiltro;

    return coincideBusqueda && coincideCategoria;
  });

  return (
    <div className="admin-layout">
      <AdminSidebar />

      <main className="admin-main">
        <AdminTopbar />

        <section className="admin-content">
          <AdminProductToolbar
            busqueda={busqueda}
            setBusqueda={setBusqueda}
            categoriaFiltro={categoriaFiltro}
            setCategoriaFiltro={setCategoriaFiltro}
            abrirNuevoProducto={abrirNuevoProducto}
          />

          {mostrarFormulario && (
            <div className="admin-form-preview">
              <ProductAdminForm
                form={form}
                errores={errores}
                editandoId={editandoId}
                loading={loading}
                handleChange={handleChange}
                handleSubmit={handleSubmit}
                limpiarFormulario={limpiarFormulario}
                cerrarFormulario={cerrarFormulario}
              />

              <ProductPreview form={form} />
            </div>
          )}

          <ProductTable
            productosFiltrados={productosFiltrados}
            productos={productos}
            editarProducto={editarProducto}
            eliminarProducto={eliminarProducto}
          />
        </section>
      </main>
    </div>
  );
};

export default AdminProducts;